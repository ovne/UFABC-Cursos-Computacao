package labvet_6i;

import java.util.Arrays;

public class Labvet_6i {
    static boolean checkPrime(int n, int vetor[]){
        for (int primo : vetor)
            if (n % primo == 0){
	        return false;
	      }
    return true;
    }
    
    public static void main(String[] args) {
	int n = Integer.parseInt(args[0]);
	int i = 1, k = 2;
 
	int primes[] = new int[n];
	Arrays.fill(primes, 2);

	while (i != n){ 
	      if(checkPrime(k, primes)){
	        primes[i] = k;
	        i++;
	      }
	      k++;
	    }
	    System.out.println(Arrays.toString(primes));
	  }
}
